﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Newtonsoft.Json;
using GenericFactory;
using InfoTrackSearch.DomainModels;

namespace InfoTrackAssignment.Controllers
{
    public class HomeController : Controller
    {
        private readonly SearchFactory _searchFactory;

        public HomeController(SearchFactory searchFactory)
        {
            this._searchFactory = searchFactory;
        }

        /// <summary>
        /// Searchfactory returns result from particular SearchEngine(e.g. Google, Bing) depending on searchEngine passed from UI
        /// </summary>
        /// <param name="searchEngine"></param>
        /// <param name="keyword"></param>
        /// <param name="exactkeyword"></param>
        /// <returns></returns>
        [HttpGet]
        public async Task<string> GetResult(string searchEngine, string keyword, string exactkeyword)
        {

            return await _searchFactory.GetSearchService(searchEngine).GetDetail(keyword, exactkeyword);
        }

        /// <summary>
        /// Return List of searchEngines fetched from Enum to UI
        /// </summary>
        /// <returns></returns>
        public ActionResult Index()
        {
            ViewBag.SearchOptions = GetEnumList();
            return View();
        }

        /// <summary>
        /// Get List of SearchEngines from Enum
        /// </summary>
        /// <returns></returns>
        private SelectList GetEnumList()
        {
            var list = from SearchEngine e in Enum.GetValues(typeof(SearchEngine))
                       select new { ID = (int)e, SearchEngine = e.ToString() };
            return new SelectList(list, "ID", "SearchEngine");
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new InfoTrackAssigment.Models.ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        /// <summary>
        /// MyStatusCode is implemented to catch exceptions with certain StatusCodes and show custom messages through MyStatusCode view.
        /// </summary>
        /// <param name="code"></param>
        /// <returns></returns>
        public IActionResult MyStatusCode(int code)
        {
            if (code == 404)
            {
                ViewBag.ErrorMessage = "The requested page not found.";
            }
            else if (code == 500)
            {
                ViewBag.ErrorMessage = "My custom 500 error message.";
            }
            else
            {
                ViewBag.ErrorMessage = "An error occurred while processing your request.";
            }

            ViewBag.RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier;
            ViewBag.ShowRequestId = !string.IsNullOrEmpty(ViewBag.RequestId);
            ViewBag.ErrorStatusCode = code;

            return View();
        }
    }
}
