﻿// Please see documentation at https://docs.microsoft.com/aspnet/core/client-side/bundling-and-minification
// for details on configuring this project to bundle and minify static web assets.

// Write your JavaScript code.

$(document).ready(function () {
    $("#divDiplayResult").hide();

    function checkValidation(keyword, searchEngine) {
        var result = true;

        $(".error").remove();
        if (keyword.length < 1) {
            $('#txtKeyword').after('<span class="error">This field is required</span>');
            result = false;
        }

        if (searchEngine.length < 1) {
            $('#searchEngine').after('<span class="error">This field is required</span>');
            result = false;
        }

        return result;
    }

    $("#calculate").click(function () {


        var searchEngine = $("#searchEngine").val();
        var keyword = $("#txtKeyword").val();
        var exactkeyword = $("#txtExactWord").val();

        if (checkValidation(keyword, searchEngine)) {

            $.ajax({
                url: "/Home/GetResult",
                method: "GET",
                data: { searchEngine: searchEngine, keyword: keyword, exactkeyword: exactkeyword },
                success: function (response) {
                    var value = response.toString();
                    $("#lblResult").html(value);
                    $("#divDiplayResult").show();
                    console.log(value);
                },
                error: function (err) {
                    console.error(err);
                }
            })
        }
    })

    $("#clearResults").click(function () {
        $("#divDiplayResult").hide();
        $("#searchEngine").prop("selectedIndex", 0);
        $("#txtKeyword").val('');
    })
});
