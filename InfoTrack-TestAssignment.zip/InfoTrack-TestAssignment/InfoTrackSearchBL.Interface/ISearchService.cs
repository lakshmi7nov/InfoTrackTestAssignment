﻿using System;
using System.Threading.Tasks;

namespace InfoTrackSearchBL.Interface
{
    /// <summary>
    /// GetDetail method must be implemented by inheriting SearchServices
    /// </summary>
    public interface ISearchService
    {
        Task<string> GetDetail(string keyword, string URLtoSearch);
    }

}
