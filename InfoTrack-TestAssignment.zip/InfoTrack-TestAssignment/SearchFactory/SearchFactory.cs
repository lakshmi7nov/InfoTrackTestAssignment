﻿using System;
using InfoTrackSearchBL;
using InfoTrackSearchBL.Interface;
using InfoTrackSearch.DomainModels;

namespace GenericFactory
{
    /// <summary>
    /// SearchFactory returning SearchEngine instance depending on searchRequest parameter from UI
    /// </summary>
    public class SearchFactory
    {
        //serviceProvider requried so that we can get service object of specified type from this factory.
        private readonly IServiceProvider serviceProvider;

        public SearchFactory(IServiceProvider serviceProvider)
        {
            this.serviceProvider = serviceProvider;
        }

        /// <summary>
        /// GoogleSearchService and BingSearchService instances are generated on demand depending on the parameter passed in the GetSearchService function below
        /// </summary>
        /// <param name="searchRequest"></param>
        /// <returns></returns>
        public ISearchService GetSearchService(string searchRequest)
        {
            SearchEngine searchEngine = (SearchEngine)Enum.Parse(typeof(SearchEngine), searchRequest);
            switch (searchEngine)
            {
                case SearchEngine.Bing:
                    {
                        return (ISearchService)serviceProvider.GetService(typeof(BingSearchService));
                    }
                case SearchEngine.Google:
                    {
                        return (ISearchService)serviceProvider.GetService(typeof(GoogleSearchService));
                    }
                default:
                    {
                        return (ISearchService)serviceProvider.GetService(typeof(BingSearchService));
                    }
            }

        }

    }

}
