﻿using System;

namespace InfoTrackSearch.DomainModels
{
    public enum SearchEngine
    {
        Google,
        Bing
    }
    
}
