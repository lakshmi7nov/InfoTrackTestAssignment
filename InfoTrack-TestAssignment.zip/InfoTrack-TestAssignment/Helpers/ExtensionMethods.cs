﻿using System;

namespace Helpers
{
    /// <summary>
    /// This class can be used for adding any extension menthods
    /// </summary>
    public static class ExtensionMethods
    {
      
    }
}
