﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.Net.Http;
using System.Linq;
using InfoTrackSearchBL.Interface;

namespace InfoTrackSearchBL
{
    public class GoogleSearchService : GenericService, ISearchService
    {
        private readonly IHttpClientFactory _clientFactory;
        /// <summary>
        /// SearchService returning data from Google pages
        /// GenericService has been inherited in case we allow BingSearch Service to do some extra stuff other than GenericServcie parse method
        /// </summary>
        /// <param name="clientFactory"></param>
        public GoogleSearchService(IHttpClientFactory clientFactory):base(clientFactory)
        {
            _clientFactory = clientFactory;
        }
        public async Task<string> GetDetail(string keyword, string urlToSearch)
        {
            var list = new List<string>();

            list.Add("https://infotrack-tests.infotrack.com.au/Google/Page01.html");
            list.Add("https://infotrack-tests.infotrack.com.au/Google/Page02.html");
            list.Add("https://infotrack-tests.infotrack.com.au/Google/Page03.html");
            list.Add("https://infotrack-tests.infotrack.com.au/Google/Page04.html");
            list.Add("https://infotrack-tests.infotrack.com.au/Google/Page05.html");
            list.Add("https://infotrack-tests.infotrack.com.au/Google/Page06.html");
            list.Add("https://infotrack-tests.infotrack.com.au/Google/Page07.html");
            list.Add("https://infotrack-tests.infotrack.com.au/Google/Page08.html");
            list.Add("https://infotrack-tests.infotrack.com.au/Google/Page09.html");
            list.Add("https://infotrack-tests.infotrack.com.au/Google/Page10.html");

            return await Parsing(list, keyword, urlToSearch);

        }
    }
}
