﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.Net.Http;
using System.Linq;
using HtmlAgilityPack;

namespace InfoTrackSearchBL
{
    /// <summary>
    /// Actual Service responsible to parse the result returned from Search
    /// </summary>
    public class GenericService
    {
        private readonly IHttpClientFactory _clientFactory;

        public GenericService(IHttpClientFactory clientFactory)
        {
            _clientFactory = clientFactory;
        }

        /// <summary>
        /// Actual function responsible to parse the result returned from Search
        /// Calculates count of the desired urlToSearch
        /// </summary>
        /// <param name="websites"></param>
        /// <param name="keyword"></param>
        /// <param name="urlToSearch"></param>
        /// <returns></returns>
        protected async Task<string> Parsing(List<string> websites, string keyword, string urlToSearch)
        {
            var occurance = new StringBuilder();
            int counter = 0;

            try
            {
                foreach (var website in websites)
                {
                    var _client = _clientFactory.CreateClient();
                    var response = await _client.GetByteArrayAsync(website);
                    String source = Encoding.GetEncoding("utf-8").GetString(response, 0, response.Length - 1);
                    source = WebUtility.HtmlDecode(source);
                    HtmlDocument resultat = new HtmlDocument();
                    resultat.LoadHtml(source);


                    // Search Only for Advertisement
                    List<HtmlNode> toftitleAddSearch = resultat.DocumentNode.Descendants().Where
                                          (x => (x.Name == "div" && x.Attributes["class"] != null &&
                                          x.Attributes["class"].Value.Contains("C4eCVc c"))).ToList();
                    if (toftitleAddSearch != null && toftitleAddSearch.Count() > 0)
                    {
                        var liAdSearch = toftitleAddSearch.FirstOrDefault().Descendants("li").ToList();

                        foreach (var item in liAdSearch)
                        {
                            counter++;
                            var linkURL = item.Descendants("a").ToList()[0].GetAttributeValue("href", null);

                            if (linkURL.Contains(urlToSearch))
                            {
                                occurance.Append(counter.ToString());
                                occurance.Append(", ");
                            }

                        }
                    }


                    // List for Main Search
                    List<HtmlNode> toftitleMainSearch = resultat.DocumentNode.Descendants().Where
                                              (x => (x.Name == "div" && x.Attributes["id"] != null &&
                                              x.Attributes["id"].Value.Contains("rso"))).ToList();
                    if (toftitleMainSearch != null && toftitleMainSearch.Count() > 0)
                    {

                        var li = toftitleMainSearch.FirstOrDefault().Descendants("div").ToList();
                        foreach (var item in li)
                        {
                            if (item.Attributes["class"] != null && item.Attributes["class"].Value == "r")
                            {
                                counter++;
                                var linkURL = item.Descendants("a").ToList()[0].GetAttributeValue("href", null);
                                if (linkURL.Contains(urlToSearch))
                                {
                                    occurance.Append(counter.ToString());
                                    occurance.Append(", ");
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }

            if (occurance.Length > 0)
            {
                return occurance.ToString().Substring(0, occurance.ToString().Trim().Length - 1);
            }
            else
            {
                return "No Data Found.";
            }

        }
    }
}
