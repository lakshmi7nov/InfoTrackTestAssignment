﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.Net.Http;
using System.Linq;
using HtmlAgilityPack;
using InfoTrackSearchBL.Interface;

namespace InfoTrackSearchBL
{
    /// <summary>
    /// SearchService returning data from Bing pages
    /// GenericService has been inherited in case we allow BingSearch Service to do some extra stuff other than GenericServcie parse method
    /// </summary>
    public class BingSearchService : GenericService, ISearchService
    {
        private readonly IHttpClientFactory _clientFactory;

        public BingSearchService(IHttpClientFactory clientFactory) : base(clientFactory)
        {
            _clientFactory = clientFactory;
        }

        public async Task<string> GetDetail(string keyword, string urlToSearch)
        {
            var list = new List<string>();

            list.Add("https://infotrack-tests.infotrack.com.au/Bing/Page01.html");
            list.Add("https://infotrack-tests.infotrack.com.au/Bing/Page02.html");
            list.Add("https://infotrack-tests.infotrack.com.au/Bing/Page03.html");
            list.Add("https://infotrack-tests.infotrack.com.au/Bing/Page04.html");
            list.Add("https://infotrack-tests.infotrack.com.au/Bing/Page05.html");
            list.Add("https://infotrack-tests.infotrack.com.au/Bing/Page06.html");
            list.Add("https://infotrack-tests.infotrack.com.au/Bing/Page07.html");
            list.Add("https://infotrack-tests.infotrack.com.au/Bing/Page08.html");
            list.Add("https://infotrack-tests.infotrack.com.au/Bing/Page09.html");
            list.Add("https://infotrack-tests.infotrack.com.au/Bing/Page10.html");

            return await Parsing(list, keyword, urlToSearch);

        }

    }
}
